﻿INSERT INTO `user_permission` (`id_user`, `id_permission`) VALUES
	(1, 1),
	(2, 1),
	(1, 2);